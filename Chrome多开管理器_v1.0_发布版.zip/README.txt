Chrome 多开管理器 v1.0.0.4

启动方式：
1. 双击 Chrome多开管理器.exe
2. 如果 exe 被安全软件拦截或无法启动，可使用 启动(备用).bat

本版更新：
- 每个 Chrome 页面左上角会显示窗口编号和当前出口 IP。
- 群控跳转、刷新、定时检查后会自动补回窗口编号/IP 标签。
- 修复多个窗口开启同步时可能退出的问题。

隐私说明：
- 发布包不包含任何账号、代理、Cookie 或浏览器配置数据。
- 用户配置保存在当前 Windows 用户的 AppData\Roaming\ChromeManager 目录。
- 代理信息需要用户在软件内自行填写或导入。

发布包内容：
- Chrome多开管理器.exe
- ChromeManager.ps1
- 启动(备用).bat
- README.txt
