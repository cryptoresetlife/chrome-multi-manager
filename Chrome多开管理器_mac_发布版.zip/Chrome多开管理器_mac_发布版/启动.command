#!/bin/bash
set -e
cd "$(dirname "$0")"
chmod +x "./Chrome多开管理器.app/Contents/MacOS/ChromeMultiManager" 2>/dev/null || true
open "./Chrome多开管理器.app"
