Chrome 多开管理器 macOS 版 1.0.0-mac.1

运行方式：
1. 解压后，右键 Chrome多开管理器.app，选择“打开”。
2. 如果无法打开，可打开终端进入本目录，执行：
   bash 启动.command

要求：
- macOS 11 或更新版本
- 已安装 Google Chrome
- 已安装 Python 3

功能：
- 每个配置使用独立 Chrome 存档：
  ~/Library/Application Support/ChromeMultiManager/Profiles/profile_编号
- 支持新建/编辑/删除配置、批量启动/关闭、导入代理。
- 支持群控跳转、群控执行 JS。
- 每个页面左上角显示窗口编号和当前出口 IP。
- 支持基础排列 Chrome 窗口；若失败，需要在：
  系统设置 -> 隐私与安全性 -> 辅助功能
  给终端或 Python 开启权限。

当前限制：
- 这是 macOS 初版，没有内置 Windows 版那种整窗鼠标/键盘同步。
- macOS 的整窗同步需要辅助功能权限和真实 Mac 环境测试，后续可继续补。

隐私：
- 发布包不包含任何账号、代理、Cookie 或浏览器配置数据。
- 用户配置仅保存到本机：
  ~/Library/Application Support/ChromeMultiManager
